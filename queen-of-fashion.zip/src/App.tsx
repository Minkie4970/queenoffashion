/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Check, 
  ArrowRight, 
  ExternalLink, 
  ShoppingBag, 
  Crown, 
  ShieldCheck, 
  Gem, 
  TrendingUp, 
  Menu, 
  X, 
  Search, 
  DollarSign, 
  ChevronRight,
  Heart,
  SlidersHorizontal,
  Compass
} from 'lucide-react';

// Verified Affiliate Destination Links
export const AFFILIATE_LINKS = {
  clothing: 'https://mavely.app.link/iCZQDDhXu7b',
  jewelry: 'https://mavely.app.link/2mU6PAKJt7b',
  skincare: 'https://mavely.app.link/EcvnMomxt7b',
  affiliateProgram: 'https://app.mave.ly/4SqybNrdt7b',
};

// Global click handler supporting GA4 and Meta Pixel tracking
export function handleAffiliateClick(
  key: keyof typeof AFFILIATE_LINKS, 
  label?: string,
  onNotify?: (message: string) => void
) {
  const url = AFFILIATE_LINKS[key];

  if (!url) {
    if (onNotify) onNotify('Affiliate destination link updating shortly.');
    return;
  }

  // 1. Google Analytics 4 tracking event
  try {
    if (typeof window !== 'undefined' && (window as unknown as { gtag?: (...args: unknown[]) => void }).gtag) {
      (window as unknown as { gtag: (...args: unknown[]) => void }).gtag('event', 'affiliate_click', {
        event_category: 'affiliate_outbound',
        event_label: label || key,
        destination_url: url,
        value: 1,
      });
    }
  } catch (err) {
    console.debug('GA4 tracking error:', err);
  }

  // 2. Meta Pixel tracking event
  try {
    if (typeof window !== 'undefined' && (window as unknown as { fbq?: (...args: unknown[]) => void }).fbq) {
      const fbq = (window as unknown as { fbq: (...args: unknown[]) => void }).fbq;
      fbq('trackCustom', 'AffiliateClick', {
        category: key,
        label: label || key,
        destination: url,
      });
      fbq('track', 'ViewContent', {
        content_name: label || key,
        content_category: key,
      });
    }
  } catch (err) {
    console.debug('Meta Pixel tracking error:', err);
  }

  // Visual feedback notification
  if (onNotify) {
    onNotify(`Redirecting to verified partner retailer for ${label || key}...`);
  }

  // Safe window open in new tab
  window.open(url, '_blank', 'noopener,noreferrer');
}

// Make accessible to window for any script requirement
if (typeof window !== 'undefined') {
  (window as unknown as { handleAffiliateClick: typeof handleAffiliateClick }).handleAffiliateClick = handleAffiliateClick;
}

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchModal, setShowSearchModal] = useState(false);

  // Trigger feedback toast
  const notify = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 4000);
  };

  // Helper smooth scroll to element
  const scrollTo = (elementId: string) => {
    setMobileMenuOpen(false);
    const target = document.getElementById(elementId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // 6 Curated Discovery Tiles
  const discoveryTiles = [
    {
      id: 'dresses',
      title: 'Designer Dresses',
      subtitle: 'Silhouettes & Eveningwear',
      linkKey: 'clothing' as const,
      image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&q=80&w=700',
      tag: 'Trending Style',
    },
    {
      id: 'accessories',
      title: 'Luxury Accessories',
      subtitle: 'Statement Handbags & Belts',
      linkKey: 'jewelry' as const,
      image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=700',
      tag: 'Wardrobe Accents',
    },
    {
      id: 'jewellery',
      title: 'Fine Jewellery',
      subtitle: 'Solid & Vermeil Gold Pieces',
      linkKey: 'jewelry' as const,
      image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&q=80&w=700',
      tag: 'Curated Gold',
    },
    {
      id: 'beauty',
      title: 'Prestige Skincare',
      subtitle: 'Glow Serums & Barrier Creams',
      linkKey: 'skincare' as const,
      image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=700',
      tag: 'Clean Beauty',
    },
    {
      id: 'trends',
      title: 'Runway Trends',
      subtitle: 'Contemporary Chic Edits',
      linkKey: 'clothing' as const,
      image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&q=80&w=700',
      tag: 'Weekly Curations',
    },
    {
      id: 'seasonal',
      title: 'Seasonal Favourites',
      subtitle: 'Tailored Coats & Cashmere',
      linkKey: 'clothing' as const,
      image: 'https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?auto=format&fit=crop&q=80&w=700',
      tag: 'Essential Layers',
    },
  ];

  // Quick search keywords mapped to categories
  const searchResults = [
    { title: 'Statement Evening Dresses', category: "Women's Clothing", linkKey: 'clothing' as const },
    { title: '18k Gold Layered Necklaces', category: 'Jewellery & Accessories', linkKey: 'jewelry' as const },
    { title: 'Hydrating Botanical Serums', category: 'Skincare & Beauty', linkKey: 'skincare' as const },
    { title: 'Tailored Trench Coats & Blazers', category: "Women's Clothing", linkKey: 'clothing' as const },
    { title: 'Sculptural Hoop Earrings', category: 'Jewellery & Accessories', linkKey: 'jewelry' as const },
    { title: 'Restorative Barrier Creams', category: 'Skincare & Beauty', linkKey: 'skincare' as const },
  ].filter(item => 
    !searchQuery.trim() || 
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#FFFDF8] text-[#242424] flex flex-col font-sans selection:bg-[#E6D3A3] selection:text-[#0D0D0D]">
      
      {/* Toast Notification for Affiliate Clicks & Info */}
      <div 
        role="status"
        aria-live="polite"
        className={`fixed top-5 right-5 z-50 transition-all duration-300 pointer-events-none transform ${
          toastMessage ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
        }`}
      >
        <div className="bg-[#0D0D0D] border border-[#C6A15B]/40 text-[#FFFDF8] px-5 py-3.5 rounded-lg shadow-2xl flex items-center gap-3 max-w-sm pointer-events-auto">
          <div className="w-7 h-7 rounded-full bg-[#C6A15B]/20 flex items-center justify-center shrink-0">
            <ExternalLink className="w-3.5 h-3.5 text-[#C6A15B]" />
          </div>
          <div className="text-xs">
            <p className="font-semibold text-[#E6D3A3]">Connecting to Verified Partner</p>
            <p className="text-stone-300 text-[11px] mt-0.5">{toastMessage}</p>
          </div>
        </div>
      </div>

      {/* Top Banner Notice */}
      <div className="bg-[#0D0D0D] text-[#E6D3A3] text-[11px] font-medium tracking-widest uppercase py-2 px-4 border-b border-[#C6A15B]/20 text-center flex items-center justify-center gap-2">
        <Sparkles className="w-3.5 h-3.5 text-[#C6A15B]" />
        <span>Curated Luxury Fashion, Fine Jewellery &amp; Clean Beauty Finds</span>
        <span className="hidden sm:inline text-stone-500">·</span>
        <span className="hidden sm:inline text-stone-300 lowercase">verified partner offers updated weekly</span>
      </div>

      {/* TOP NAVIGATION BAR */}
      <header className="sticky top-0 z-40 bg-[#FFFDF8]/95 backdrop-blur-md border-b border-[#C6A15B]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
          
          {/* Brand Wordmark Zone */}
          <a 
            href="#home" 
            onClick={(e) => { e.preventDefault(); scrollTo('home'); }} 
            className="group flex items-center gap-2.5 focus:outline-none shrink-0" 
            aria-label="Queen of Fashion Home"
          >
            <div className="w-8 h-8 rounded-full bg-[#0D0D0D] flex items-center justify-center border border-[#C6A15B]/40 group-hover:scale-105 transition-transform">
              <Crown className="w-4 h-4 text-[#C6A15B]" />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#0D0D0D]">
                Queen of <span className="gold-gradient-text">Fashion</span>
              </span>
            </div>
          </a>

          {/* Nav Links (Single-Line, 4-5 items) */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-stone-700 whitespace-nowrap">
            <button 
              onClick={() => scrollTo('trending')} 
              className="hover:text-[#C6A15B] transition-colors py-1 cursor-pointer whitespace-nowrap"
            >
              Trending Finds
            </button>
            <button 
              onClick={() => handleAffiliateClick('clothing', "Women's Clothing", notify)} 
              className="hover:text-[#C6A15B] transition-colors py-1 cursor-pointer whitespace-nowrap"
            >
              Clothing
            </button>
            <button 
              onClick={() => handleAffiliateClick('jewelry', 'Jewellery & Accessories', notify)} 
              className="hover:text-[#C6A15B] transition-colors py-1 cursor-pointer whitespace-nowrap"
            >
              Jewellery
            </button>
            <button 
              onClick={() => handleAffiliateClick('skincare', 'Skincare & Beauty', notify)} 
              className="hover:text-[#C6A15B] transition-colors py-1 cursor-pointer whitespace-nowrap"
            >
              Skincare
            </button>
            <button 
              onClick={() => scrollTo('monetize')} 
              className="text-[#9A7736] hover:text-[#0D0D0D] font-semibold transition-colors py-1 cursor-pointer whitespace-nowrap flex items-center gap-1.5"
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>Creator Program</span>
            </button>
          </nav>

          {/* Action Button & Search */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <button 
              onClick={() => setShowSearchModal(true)}
              className="p-2 text-stone-600 hover:text-[#0D0D0D] hover:bg-[#F3EEE7] rounded-full transition-colors cursor-pointer"
              title="Search curated recommendations"
              aria-label="Search curated recommendations"
            >
              <Search className="w-4 h-4" />
            </button>

            <button
              onClick={() => handleAffiliateClick('affiliateProgram', 'Partner Application', notify)}
              className="bg-[#0D0D0D] text-[#E6D3A3] hover:bg-[#C6A15B] hover:text-[#0D0D0D] px-5 py-2.5 rounded-full transition-all duration-300 text-xs font-semibold tracking-wider uppercase border border-[#C6A15B]/30 shadow-sm cursor-pointer whitespace-nowrap flex items-center gap-1.5"
            >
              <span>Become an Affiliate</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex sm:hidden items-center gap-2">
            <button 
              onClick={() => setShowSearchModal(true)}
              className="p-2 text-stone-700 hover:text-[#0D0D0D] focus:outline-none"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-stone-800 hover:text-[#C6A15B] focus:outline-none"
              aria-label="Toggle navigation menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#FFFDF8] border-b border-[#C6A15B]/20 px-6 py-5 space-y-4 shadow-xl">
            <button 
              onClick={() => scrollTo('trending')} 
              className="block w-full text-left text-base font-medium text-stone-800 hover:text-[#C6A15B] py-1"
            >
              Trending Finds
            </button>
            <button 
              onClick={() => { setMobileMenuOpen(false); handleAffiliateClick('clothing', "Women's Clothing", notify); }} 
              className="block w-full text-left text-base font-medium text-stone-800 hover:text-[#C6A15B] py-1"
            >
              Women's Clothing
            </button>
            <button 
              onClick={() => { setMobileMenuOpen(false); handleAffiliateClick('jewelry', 'Jewellery & Accessories', notify); }} 
              className="block w-full text-left text-base font-medium text-stone-800 hover:text-[#C6A15B] py-1"
            >
              Jewellery &amp; Accessories
            </button>
            <button 
              onClick={() => { setMobileMenuOpen(false); handleAffiliateClick('skincare', 'Skincare & Beauty', notify); }} 
              className="block w-full text-left text-base font-medium text-stone-800 hover:text-[#C6A15B] py-1"
            >
              Skincare &amp; Beauty
            </button>
            <button 
              onClick={() => scrollTo('monetize')} 
              className="block w-full text-left text-base font-semibold text-[#9A7736] py-1"
            >
              Creator Monetization Opportunity
            </button>

            <div className="pt-2">
              <button 
                onClick={() => { setMobileMenuOpen(false); handleAffiliateClick('affiliateProgram', 'Partner Application', notify); }}
                className="w-full text-center bg-[#0D0D0D] text-[#E6D3A3] hover:bg-[#C6A15B] hover:text-[#0D0D0D] py-3.5 rounded-lg text-xs font-semibold tracking-widest uppercase transition-colors"
              >
                Become an Affiliate – Start Earning
              </button>
            </div>
          </div>
        )}
      </header>

      {/* QUICK SEARCH & FIND MODAL */}
      {showSearchModal && (
        <div className="fixed inset-0 z-50 bg-[#0D0D0D]/70 backdrop-blur-sm flex items-start justify-center pt-20 px-4">
          <div className="bg-[#FFFDF8] border border-[#C6A15B]/30 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-stone-200 pb-4 mb-4">
              <div className="flex items-center gap-2">
                <Search className="w-5 h-5 text-[#C6A15B]" />
                <h3 className="font-serif text-lg font-semibold text-[#0D0D0D]">Quick Discovery Search</h3>
              </div>
              <button 
                onClick={() => setShowSearchModal(false)}
                className="p-1 rounded-full text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative mb-4">
              <input 
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search dresses, gold hoops, serum, blazers..."
                className="w-full bg-[#F3EEE7] border border-stone-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-[#C6A15B] transition-colors"
                autoFocus
              />
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-stone-500 mb-1">
                Suggested Curated Finds
              </p>
              {searchResults.length > 0 ? (
                searchResults.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setShowSearchModal(false);
                      handleAffiliateClick(item.linkKey, item.title, notify);
                    }}
                    className="w-full text-left p-3 rounded-lg hover:bg-[#F3EEE7] flex items-center justify-between group transition-colors"
                  >
                    <div>
                      <p className="text-sm font-medium text-[#0D0D0D] group-hover:text-[#9A7736]">{item.title}</p>
                      <p className="text-xs text-stone-500">{item.category}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-stone-400 group-hover:text-[#9A7736] group-hover:translate-x-1 transition-all" />
                  </button>
                ))
              ) : (
                <div className="py-6 text-center text-sm text-stone-500">
                  No matching keywords found. Explore our main collections below.
                </div>
              )}
            </div>

            <div className="mt-5 pt-3 border-t border-stone-200 flex justify-end">
              <button 
                onClick={() => {
                  setShowSearchModal(false);
                  scrollTo('trending');
                }}
                className="text-xs font-semibold text-[#9A7736] hover:underline"
              >
                Browse All Trending Finds &rarr;
              </button>
            </div>
          </div>
        </div>
      )}

      <main id="home" className="flex-grow">
        
        {/* ========================================================== */}
        {/* SECTION 1 - CONVERSION HERO                                */}
        {/* ========================================================== */}
        <section className="relative pt-10 pb-16 md:pt-16 md:pb-24 overflow-hidden border-b border-[#C6A15B]/15">
          {/* Subtle Ambient Glow */}
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#C6A15B]/5 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute bottom-0 left-10 w-80 h-80 bg-[#F7E9E9]/40 rounded-full blur-2xl pointer-events-none"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
              
              {/* Left Column: Conversion Copy */}
              <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
                
                {/* Urgency Badge */}
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F7E9E9] border border-[#C6A15B]/30 text-xs font-semibold text-[#0D0D0D] tracking-wide">
                  <span className="text-[#C6A15B]">✨</span>
                  <span>Updated Weekly With New Fashion Finds</span>
                </div>

                {/* Primary Headline */}
                <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#0D0D0D] leading-[1.12]">
                  Discover Fashion Finds You'll <span className="font-editorial italic font-normal text-[#C6A15B]">Absolutely Love</span>
                </h1>

                {/* Subheadline */}
                <p className="text-base sm:text-lg text-stone-600 max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
                  We've handpicked the most stylish fashion pieces, beauty favourites and accessories from trusted retailers so you can spend less time searching and more time discovering.
                </p>

                {/* Quick Interactive Shortcut Badges */}
                <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 pt-1 text-xs text-stone-600">
                  <span className="font-semibold text-stone-500 uppercase tracking-wider text-[11px]">Quick Jump:</span>
                  <button 
                    onClick={() => handleAffiliateClick('clothing', 'Evening Dresses', notify)}
                    className="px-2.5 py-1 rounded bg-[#F3EEE7] hover:bg-[#E6D3A3]/40 border border-stone-200 transition-colors"
                  >
                    Dresses &rarr;
                  </button>
                  <button 
                    onClick={() => handleAffiliateClick('jewelry', '18k Gold Vermeil', notify)}
                    className="px-2.5 py-1 rounded bg-[#F3EEE7] hover:bg-[#E6D3A3]/40 border border-stone-200 transition-colors"
                  >
                    Gold Jewellery &rarr;
                  </button>
                  <button 
                    onClick={() => handleAffiliateClick('skincare', 'Clean Skincare', notify)}
                    className="px-2.5 py-1 rounded bg-[#F3EEE7] hover:bg-[#E6D3A3]/40 border border-stone-200 transition-colors"
                  >
                    Skincare &rarr;
                  </button>
                </div>

                {/* CTAs */}
                <div className="pt-3 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                  <button
                    onClick={() => scrollTo('trending')}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#0D0D0D] text-[#FFFDF8] hover:bg-[#C6A15B] hover:text-[#0D0D0D] font-semibold text-xs sm:text-sm tracking-widest uppercase rounded-full transition-all duration-300 shadow-xl cursor-pointer group"
                  >
                    <ShoppingBag className="w-4 h-4 text-[#C6A15B] group-hover:text-[#0D0D0D]" />
                    <span>Shop Trending Finds</span>
                  </button>

                  <button
                    onClick={() => scrollTo('discovery')}
                    className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-4 text-[#0D0D0D] hover:text-[#C6A15B] font-semibold text-xs sm:text-sm tracking-wider underline underline-offset-8 decoration-[#C6A15B]/50 hover:decoration-[#C6A15B] transition-colors cursor-pointer"
                  >
                    <span>Browse Categories &rarr;</span>
                  </button>
                </div>

                {/* Trust mini-note */}
                <div className="pt-2 text-[12px] text-stone-500 flex items-center justify-center lg:justify-start gap-3">
                  <span className="flex items-center gap-1 text-emerald-700 font-medium">
                    <Check className="w-3.5 h-3.5" /> 100% Curated Selections
                  </span>
                  <span>·</span>
                  <span>Verified Outbound Partner Retailers</span>
                </div>
              </div>

              {/* Right Column: High-Impact Visual Showcase */}
              <div className="lg:col-span-5 relative">
                <div className="relative mx-auto max-w-md lg:max-w-none">
                  
                  {/* Decorative Frame */}
                  <div className="absolute -inset-2.5 rounded-2xl bg-gradient-to-tr from-[#C6A15B]/30 via-[#F7E9E9] to-[#E6D3A3]/20 transform rotate-1 border border-[#C6A15B]/30"></div>
                  
                  {/* Image Card Container */}
                  <div className="relative rounded-xl overflow-hidden shadow-2xl aspect-[4/5] bg-stone-100 group">
                    <img 
                      src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=1000" 
                      alt="Luxury high-fashion editorial curated style" 
                      className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-700"
                      loading="eager"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Dark gradient scrim for legibility */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/15 to-transparent"></div>

                    {/* Floating Trust Badge on image */}
                    <div className="absolute top-4 right-4 bg-[#0D0D0D]/85 backdrop-blur-md text-[#E6D3A3] text-[10px] tracking-widest uppercase font-semibold px-3 py-1.5 rounded-full border border-[#C6A15B]/40 shadow-lg">
                      Weekly Editor's Choice
                    </div>

                    {/* Bottom Feature Card */}
                    <div className="absolute bottom-5 left-5 right-5 text-[#FFFDF8] backdrop-blur-md bg-black/40 border border-white/20 p-4 rounded-xl">
                      <div className="flex items-center justify-between text-xs pb-2 border-b border-white/15">
                        <span className="uppercase tracking-widest text-[#E6D3A3] font-semibold text-[10px]">
                          Curated Category
                        </span>
                        <span className="text-[11px] text-stone-300">Verified Retail Partners</span>
                      </div>
                      <div className="pt-2 flex items-center justify-between">
                        <div>
                          <p className="font-serif text-base font-semibold">Elevated Wardrobe Essentials</p>
                          <p className="text-[11px] text-stone-300">Dresses · Outerwear · Tailoring</p>
                        </div>
                        <button
                          onClick={() => handleAffiliateClick('clothing', 'Hero Feature', notify)}
                          className="bg-[#C6A15B] text-[#0D0D0D] hover:bg-[#FFFDF8] px-3.5 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shrink-0"
                        >
                          Shop &rarr;
                        </button>
                      </div>
                    </div>

                  </div>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* ========================================================== */}
        {/* SECTION 2 - TRUST BAR                                      */}
        {/* ========================================================== */}
        <section className="py-6 bg-[#F3EEE7]/70 border-b border-[#C6A15B]/20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 items-center">
              
              <div className="flex items-center gap-3 justify-center md:justify-start">
                <div className="w-8 h-8 rounded-full bg-[#0D0D0D] flex items-center justify-center shrink-0 text-[#C6A15B]">
                  <Check className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <p className="text-xs sm:text-sm font-bold text-[#0D0D0D] leading-tight">Curated Fashion Finds</p>
                  <p className="text-[11px] text-stone-500 hidden sm:block">Editor-approved pieces</p>
                </div>
              </div>

              <div className="flex items-center gap-3 justify-center md:justify-start">
                <div className="w-8 h-8 rounded-full bg-[#0D0D0D] flex items-center justify-center shrink-0 text-[#C6A15B]">
                  <Check className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <p className="text-xs sm:text-sm font-bold text-[#0D0D0D] leading-tight">Trusted Retail Partners</p>
                  <p className="text-[11px] text-stone-500 hidden sm:block">Verified direct checkouts</p>
                </div>
              </div>

              <div className="flex items-center gap-3 justify-center md:justify-start">
                <div className="w-8 h-8 rounded-full bg-[#0D0D0D] flex items-center justify-center shrink-0 text-[#C6A15B]">
                  <Check className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <p className="text-xs sm:text-sm font-bold text-[#0D0D0D] leading-tight">Trending Beauty Picks</p>
                  <p className="text-[11px] text-stone-500 hidden sm:block">Dermatologist-tested favourites</p>
                </div>
              </div>

              <div className="flex items-center gap-3 justify-center md:justify-start">
                <div className="w-8 h-8 rounded-full bg-[#0D0D0D] flex items-center justify-center shrink-0 text-[#C6A15B]">
                  <Check className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <p className="text-xs sm:text-sm font-bold text-[#0D0D0D] leading-tight">Updated Weekly</p>
                  <p className="text-[11px] text-stone-500 hidden sm:block">Fresh season discoveries</p>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* ========================================================== */}
        {/* SECTION 3 - TRENDING RIGHT NOW (CATEGORY CARDS)           */}
        {/* ========================================================== */}
        <section id="trending" className="py-16 md:py-24 bg-[#FFFDF8]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            
            {/* Header */}
            <div className="text-center space-y-3 mb-14">
              <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#C6A15B]">
                Curated Recommendations
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0D0D0D]">
                Trending Right Now
              </h2>
              <p className="text-stone-600 max-w-xl mx-auto text-sm sm:text-base">
                Most popular categories our visitors are exploring.
              </p>
            </div>

            {/* 3 Main Category Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              
              {/* CARD 1: WOMEN'S CLOTHING */}
              <div className="card-hover group bg-white rounded-2xl overflow-hidden border border-[#C6A15B]/25 shadow-sm flex flex-col h-full">
                <div className="relative aspect-[4/3] overflow-hidden bg-stone-100">
                  <img 
                    src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=800" 
                    alt="Modern woman wearing fashionable elegant attire" 
                    className="img-zoom w-full h-full object-cover object-top"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 left-4 bg-[#0D0D0D]/85 backdrop-blur-md text-[#E6D3A3] text-[10px] font-semibold tracking-widest uppercase px-3 py-1 rounded">
                    Wardrobe Essentials
                  </div>
                  <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm text-[#0D0D0D] text-[11px] font-medium px-2.5 py-1 rounded shadow-sm">
                    150+ Verified Picks
                  </div>
                </div>

                <div className="p-7 flex flex-col flex-grow justify-between space-y-6">
                  <div className="space-y-3">
                    <h3 className="font-serif text-2xl text-[#0D0D0D] font-bold">Women's Clothing</h3>
                    <p className="text-stone-600 text-sm leading-relaxed">
                      Discover gorgeous outfits, statement dresses, everyday essentials, and the latest styles to elevate your wardrobe.
                    </p>
                    <div className="pt-1 flex flex-wrap gap-1.5 text-[11px] text-stone-500">
                      <span>• Statement Dresses</span>
                      <span>• Tailored Blazers</span>
                      <span>• Casual Luxe</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => handleAffiliateClick('clothing', "Women's Clothing", notify)}
                    className="w-full py-4 bg-[#0D0D0D] text-[#FFFDF8] group-hover:bg-[#C6A15B] group-hover:text-[#0D0D0D] transition-colors duration-300 font-semibold text-xs tracking-widest uppercase rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    <span>See Today's Fashion Picks &rarr;</span>
                  </button>
                </div>
              </div>

              {/* CARD 2: JEWELLERY & ACCESSORIES */}
              <div className="card-hover group bg-white rounded-2xl overflow-hidden border border-[#C6A15B]/25 shadow-sm flex flex-col h-full">
                <div className="relative aspect-[4/3] overflow-hidden bg-stone-100">
                  <img 
                    src="https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&q=80&w=800" 
                    alt="Close-up of elegant gold jewelry and necklaces" 
                    className="img-zoom w-full h-full object-cover"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 left-4 bg-[#0D0D0D]/85 backdrop-blur-md text-[#E6D3A3] text-[10px] font-semibold tracking-widest uppercase px-3 py-1 rounded">
                    Timeless Accents
                  </div>
                  <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm text-[#0D0D0D] text-[11px] font-medium px-2.5 py-1 rounded shadow-sm">
                    Solid &amp; Vermeil Gold
                  </div>
                </div>

                <div className="p-7 flex flex-col flex-grow justify-between space-y-6">
                  <div className="space-y-3">
                    <h3 className="font-serif text-2xl text-[#0D0D0D] font-bold">Jewellery &amp; Accessories</h3>
                    <p className="text-stone-600 text-sm leading-relaxed">
                      Find the finishing touches that make every outfit special, from timeless jewelry to eye-catching accessories.
                    </p>
                    <div className="pt-1 flex flex-wrap gap-1.5 text-[11px] text-stone-500">
                      <span>• Layered Chains</span>
                      <span>• Sculptural Hoops</span>
                      <span>• Designer Bags</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => handleAffiliateClick('jewelry', 'Jewellery & Accessories', notify)}
                    className="w-full py-4 bg-[#0D0D0D] text-[#FFFDF8] group-hover:bg-[#C6A15B] group-hover:text-[#0D0D0D] transition-colors duration-300 font-semibold text-xs tracking-widest uppercase rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    <span>Explore Trending Jewellery &rarr;</span>
                  </button>
                </div>
              </div>

              {/* CARD 3: SKINCARE & BEAUTY */}
              <div className="card-hover group bg-white rounded-2xl overflow-hidden border border-[#C6A15B]/25 shadow-sm flex flex-col h-full">
                <div className="relative aspect-[4/3] overflow-hidden bg-stone-100">
                  <img 
                    src="https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&q=80&w=800" 
                    alt="Luxury skincare bottles and cosmetic products layout" 
                    className="img-zoom w-full h-full object-cover"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 left-4 bg-[#0D0D0D]/85 backdrop-blur-md text-[#E6D3A3] text-[10px] font-semibold tracking-widest uppercase px-3 py-1 rounded">
                    Self-Care Rituals
                  </div>
                  <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm text-[#0D0D0D] text-[11px] font-medium px-2.5 py-1 rounded shadow-sm">
                    Dermatology Approved
                  </div>
                </div>

                <div className="p-7 flex flex-col flex-grow justify-between space-y-6">
                  <div className="space-y-3">
                    <h3 className="font-serif text-2xl text-[#0D0D0D] font-bold">Skincare &amp; Beauty</h3>
                    <p className="text-stone-600 text-sm leading-relaxed">
                      Explore beauty essentials and skincare favourites to complement your routine and complete your self-care ritual.
                    </p>
                    <div className="pt-1 flex flex-wrap gap-1.5 text-[11px] text-stone-500">
                      <span>• Glow Serums</span>
                      <span>• Barrier Balms</span>
                      <span>• Luminous Tints</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => handleAffiliateClick('skincare', 'Skincare & Beauty', notify)}
                    className="w-full py-4 bg-[#0D0D0D] text-[#FFFDF8] group-hover:bg-[#C6A15B] group-hover:text-[#0D0D0D] transition-colors duration-300 font-semibold text-xs tracking-widest uppercase rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    <span>Discover Beauty Favourites &rarr;</span>
                  </button>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* ========================================================== */}
        {/* SECTION 4 - FEATURED MONEY-MAKING OPPORTUNITY              */}
        {/* (Must be one of the most visible sections on the page!)   */}
        {/* ========================================================== */}
        <section id="monetize" className="py-20 md:py-28 bg-[#0D0D0D] text-[#FFFDF8] relative overflow-hidden border-y-2 border-[#C6A15B]">
          
          {/* Gold Decorative Ambience */}
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-[#C6A15B]/20 via-transparent to-transparent pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-gradient-to-tr from-[#9A7736]/20 via-transparent to-transparent pointer-events-none"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              
              {/* Left Column: Compelling Pitch & Proof */}
              <div className="lg:col-span-7 space-y-6">
                
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#1A1A1A] border border-[#C6A15B]/60 text-xs font-bold uppercase tracking-widest text-[#E6D3A3]">
                  <Crown className="w-3.5 h-3.5 text-[#C6A15B]" />
                  <span>Featured Partner Opportunity</span>
                </div>

                <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-tight">
                  Turn Your Love For Fashion <br className="hidden sm:inline" />
                  <span className="gold-gradient-text">Into Income</span>
                </h2>

                <p className="text-base sm:text-lg text-stone-300 max-w-xl font-normal leading-relaxed">
                  Discover how fashion lovers and creators are earning commissions by sharing products they genuinely love.
                </p>

                {/* 4 Compelling Bullet Points */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-[#171717] border border-[#C6A15B]/30">
                    <div className="w-6 h-6 rounded-full bg-[#C6A15B] text-[#0D0D0D] flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                    <span className="text-sm font-semibold text-stone-100">Beginner Friendly</span>
                  </div>

                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-[#171717] border border-[#C6A15B]/30">
                    <div className="w-6 h-6 rounded-full bg-[#C6A15B] text-[#0D0D0D] flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                    <span className="text-sm font-semibold text-stone-100">No Inventory Required</span>
                  </div>

                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-[#171717] border border-[#C6A15B]/30">
                    <div className="w-6 h-6 rounded-full bg-[#C6A15B] text-[#0D0D0D] flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                    <span className="text-sm font-semibold text-stone-100">Work From Anywhere</span>
                  </div>

                  <div className="flex items-center gap-3 p-3.5 rounded-xl bg-[#171717] border border-[#C6A15B]/30">
                    <div className="w-6 h-6 rounded-full bg-[#C6A15B] text-[#0D0D0D] flex items-center justify-center shrink-0">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                    <span className="text-sm font-semibold text-stone-100">Share Products You Love</span>
                  </div>
                </div>

                {/* High-Impact CTA Button */}
                <div className="pt-4 flex flex-col sm:flex-row items-center gap-4">
                  <button
                    onClick={() => handleAffiliateClick('affiliateProgram', 'Featured Money Making Opportunity', notify)}
                    className="w-full sm:w-auto px-10 py-5 bg-gradient-to-r from-[#C6A15B] via-[#E6D3A3] to-[#B8924B] text-[#0D0D0D] hover:brightness-110 font-bold text-sm tracking-widest uppercase rounded-full transition-all duration-300 shadow-2xl gold-border-glow flex items-center justify-center gap-3 cursor-pointer group"
                  >
                    <span>Start Earning Today &rarr;</span>
                  </button>

                  <span className="text-xs text-stone-400">
                    Free instant creator sign-up · No upfront costs
                  </span>
                </div>

              </div>

              {/* Right Column: Visual Showcase of Creator Earnings Model */}
              <div className="lg:col-span-5">
                <div className="relative bg-gradient-to-b from-[#1C1C1C] to-[#141414] border-2 border-[#C6A15B]/50 rounded-2xl p-6 sm:p-8 shadow-2xl">
                  
                  {/* Subtle Top Crown Tag */}
                  <div className="flex items-center justify-between pb-6 border-b border-[#C6A15B]/20">
                    <div className="flex items-center gap-2">
                      <Crown className="w-5 h-5 text-[#C6A15B]" />
                      <span className="font-serif text-lg font-bold text-white">Creator Network</span>
                    </div>
                    <span className="text-xs font-semibold px-2.5 py-1 rounded bg-[#C6A15B]/20 text-[#E6D3A3] border border-[#C6A15B]/30">
                      Mavely Affiliate Partner
                    </span>
                  </div>

                  {/* 3 Step Workflow */}
                  <div className="py-6 space-y-4">
                    <div className="flex items-start gap-4">
                      <span className="w-7 h-7 rounded-full bg-[#C6A15B]/20 text-[#C6A15B] font-bold text-xs flex items-center justify-center shrink-0 border border-[#C6A15B]/40">
                        1
                      </span>
                      <div>
                        <h4 className="text-sm font-bold text-white">Pick What You Adore</h4>
                        <p className="text-xs text-stone-400">Select fashion, dresses, jewellery or skincare from thousands of trusted top-tier retail brands.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <span className="w-7 h-7 rounded-full bg-[#C6A15B]/20 text-[#C6A15B] font-bold text-xs flex items-center justify-center shrink-0 border border-[#C6A15B]/40">
                        2
                      </span>
                      <div>
                        <h4 className="text-sm font-bold text-white">Share Your Link</h4>
                        <p className="text-xs text-stone-400">Share your recommendations on Instagram, TikTok, Pinterest, blogs, or with friends.</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <span className="w-7 h-7 rounded-full bg-[#C6A15B]/20 text-[#C6A15B] font-bold text-xs flex items-center justify-center shrink-0 border border-[#C6A15B]/40">
                        3
                      </span>
                      <div>
                        <h4 className="text-sm font-bold text-white">Earn On Every Sale</h4>
                        <p className="text-xs text-stone-400">Receive verified commission payouts directly whenever your audience shops through your links.</p>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Highlight Box */}
                  <div className="mt-2 p-4 rounded-xl bg-[#0D0D0D] border border-[#C6A15B]/30 flex items-center justify-between">
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-stone-400">Average Commission</p>
                      <p className="font-serif text-xl font-bold text-[#E6D3A3]">Competitive Rates</p>
                    </div>
                    <button
                      onClick={() => handleAffiliateClick('affiliateProgram', 'Side Box Join', notify)}
                      className="px-4 py-2 bg-[#C6A15B] text-[#0D0D0D] rounded-lg text-xs font-bold uppercase tracking-wider hover:bg-white transition-colors cursor-pointer"
                    >
                      Apply Now
                    </button>
                  </div>

                </div>
              </div>

            </div>
          </div>
        </section>

        {/* ========================================================== */}
        {/* SECTION 5 - WHY SHOP WITH QUEEN OF FASHION                */}
        {/* ========================================================== */}
        <section className="py-20 md:py-28 bg-[#F3EEE7]/50 border-b border-[#C6A15B]/15">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            
            <div className="text-center space-y-3 mb-16">
              <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#C6A15B]">
                The Gold Standard Difference
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0D0D0D]">
                Why Shop With Queen of Fashion
              </h2>
              <p className="text-stone-600 max-w-xl mx-auto text-sm sm:text-base">
                Curating the world's most desired pieces into one seamless shopping journey.
              </p>
            </div>

            {/* 3 Premium Value Propositions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              
              {/* Prop 1 */}
              <div className="bg-white p-8 sm:p-10 rounded-2xl border border-[#C6A15B]/25 shadow-sm text-center space-y-5 hover:border-[#C6A15B] transition-colors card-hover">
                <div className="w-14 h-14 mx-auto rounded-full bg-[#F7E9E9] border border-[#C6A15B]/30 flex items-center justify-center text-[#C6A15B]">
                  <Sparkles className="w-7 h-7" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#0D0D0D]">
                  Handpicked Recommendations
                </h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Every product category is carefully selected to help you discover fashionable pieces worth exploring.
                </p>
                <div className="pt-2 text-xs font-semibold text-[#9A7736] flex items-center justify-center gap-1">
                  <span>Quality over clutter</span>
                  <Check className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Prop 2 */}
              <div className="bg-white p-8 sm:p-10 rounded-2xl border border-[#C6A15B]/25 shadow-sm text-center space-y-5 hover:border-[#C6A15B] transition-colors card-hover">
                <div className="w-14 h-14 mx-auto rounded-full bg-[#F7E9E9] border border-[#C6A15B]/30 flex items-center justify-center text-[#C6A15B]">
                  <TrendingUp className="w-7 h-7" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#0D0D0D]">
                  Luxury Style Inspiration
                </h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Stay inspired with current trends, timeless classics, and editor-approved favourites.
                </p>
                <div className="pt-2 text-xs font-semibold text-[#9A7736] flex items-center justify-center gap-1">
                  <span>Runway to wardrobe</span>
                  <Check className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Prop 3 */}
              <div className="bg-white p-8 sm:p-10 rounded-2xl border border-[#C6A15B]/25 shadow-sm text-center space-y-5 hover:border-[#C6A15B] transition-colors card-hover">
                <div className="w-14 h-14 mx-auto rounded-full bg-[#F7E9E9] border border-[#C6A15B]/30 flex items-center justify-center text-[#C6A15B]">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-[#0D0D0D]">
                  Trusted Discoveries
                </h3>
                <p className="text-stone-600 text-sm leading-relaxed">
                  Browse recommendations from established retail partners in one convenient destination.
                </p>
                <div className="pt-2 text-xs font-semibold text-[#9A7736] flex items-center justify-center gap-1">
                  <span>Verified checkouts</span>
                  <Check className="w-3.5 h-3.5" />
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* ========================================================== */}
        {/* SECTION 6 - FASHION DISCOVERY GRID (6 CLICKABLE TILES)     */}
        {/* ========================================================== */}
        <section id="discovery" className="py-20 md:py-28 bg-[#FFFDF8]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-14">
            
            <div className="text-center space-y-3">
              <span className="text-xs font-bold uppercase tracking-[0.25em] text-[#C6A15B]">
                Curated Style Moodboard
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0D0D0D]">
                Explore Fashion Inspiration
              </h2>
              <p className="text-stone-600 max-w-xl mx-auto text-sm sm:text-base">
                Click any style edit below to browse verified recommendations directly.
              </p>
            </div>

            {/* 6 Luxury Clickable Tiles */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-5 sm:gap-7">
              {discoveryTiles.map((tile) => (
                <div
                  key={tile.id}
                  onClick={() => handleAffiliateClick(tile.linkKey, tile.title, notify)}
                  className="group relative aspect-[3/4] overflow-hidden rounded-2xl bg-stone-100 shadow-md cursor-pointer border border-[#C6A15B]/20 card-hover"
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleAffiliateClick(tile.linkKey, tile.title, notify);
                    }
                  }}
                  aria-label={`Shop ${tile.title}`}
                >
                  <img 
                    src={tile.image} 
                    alt={tile.title} 
                    className="w-full h-full object-cover img-zoom"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Scrim Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent opacity-90 group-hover:opacity-95 transition-opacity"></div>
                  
                  {/* Top Badge */}
                  <span className="absolute top-4 left-4 text-[#E6D3A3] text-[10px] font-bold tracking-widest uppercase bg-[#0D0D0D]/80 backdrop-blur-md px-2.5 py-1 rounded border border-[#C6A15B]/30">
                    {tile.tag}
                  </span>

                  {/* Bottom Title & Action */}
                  <div className="absolute bottom-5 left-5 right-5 text-white space-y-1.5">
                    <h3 className="font-serif text-lg sm:text-xl font-bold leading-tight group-hover:text-[#E6D3A3] transition-colors">
                      {tile.title}
                    </h3>
                    <p className="text-xs text-stone-300 hidden sm:block">
                      {tile.subtitle}
                    </p>
                    <div className="pt-2 flex items-center gap-1.5 text-xs font-semibold text-[#C6A15B] group-hover:translate-x-1 transition-transform">
                      <span>Shop This Edit</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Sub-note encouraging clicks */}
            <div className="text-center pt-2">
              <button
                onClick={() => handleAffiliateClick('clothing', 'Full Collection Discovery', notify)}
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full border border-[#0D0D0D] text-xs font-bold uppercase tracking-widest text-[#0D0D0D] hover:bg-[#0D0D0D] hover:text-[#FFFDF8] transition-colors cursor-pointer"
              >
                <span>Browse All Partner Retailers</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>
        </section>

        {/* ========================================================== */}
        {/* SECTION 7 - FINAL CALL TO ACTION                           */}
        {/* ========================================================== */}
        <section className="py-20 md:py-28 bg-gradient-to-b from-[#F7E9E9]/60 via-[#F3EEE7] to-[#FFFDF8] border-t border-[#C6A15B]/30 relative overflow-hidden">
          
          <div className="max-w-4xl mx-auto px-4 text-center space-y-8 relative z-10">
            
            <div className="w-12 h-12 mx-auto rounded-full bg-[#0D0D0D] flex items-center justify-center text-[#C6A15B] border border-[#C6A15B]/40 shadow-md">
              <Crown className="w-6 h-6" />
            </div>

            <div className="space-y-4">
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0D0D0D]">
                Your Next Favourite Find Is Waiting
              </h2>
              <p className="text-stone-700 text-base sm:text-lg max-w-xl mx-auto font-normal leading-relaxed">
                Explore our most loved fashion, jewellery and beauty recommendations today.
              </p>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
              <button
                onClick={() => handleAffiliateClick('clothing', 'Final CTA Collection', notify)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-10 py-5 bg-[#0D0D0D] text-[#FFFDF8] hover:bg-[#C6A15B] hover:text-[#0D0D0D] font-bold text-xs sm:text-sm tracking-widest uppercase rounded-full transition-all duration-300 shadow-2xl cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4 text-[#C6A15B]" />
                <span>Shop The Collection</span>
              </button>

              <button
                onClick={() => handleAffiliateClick('affiliateProgram', 'Final CTA Creator Program', notify)}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-5 bg-white text-[#0D0D0D] hover:bg-[#F3EEE7] border border-stone-300 font-bold text-xs sm:text-sm tracking-wider uppercase rounded-full transition-colors cursor-pointer"
              >
                <DollarSign className="w-4 h-4 text-[#9A7736]" />
                <span>Become an Affiliate</span>
              </button>
            </div>

            <p className="text-xs tracking-widest uppercase text-[#9A7736] font-semibold font-serif italic pt-4">
              Curated with elegance · Gold standard quality
            </p>

          </div>
        </section>

      </main>

      {/* ========================================================== */}
      {/* SECTION 8 - FOOTER & AFFILIATE DISCLOSURE                  */}
      {/* ========================================================== */}
      <footer className="bg-[#0D0D0D] text-[#FFFDF8] border-t border-[#C6A15B]/30 pt-16 pb-20 md:pb-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
            
            {/* Brand Information */}
            <div className="md:col-span-6 space-y-4">
              <div className="flex items-center gap-2.5">
                <Crown className="w-6 h-6 text-[#C6A15B]" />
                <span className="font-serif text-2xl font-bold tracking-tight text-white">
                  Queen of <span className="gold-gradient-text">Fashion</span>
                </span>
              </div>
              <p className="text-xs uppercase tracking-[0.2em] text-[#C6A15B] font-semibold">
                Gold Standard Fashion Finds
              </p>
              <p className="text-stone-400 text-sm leading-relaxed max-w-sm pt-1">
                Your destination for curated women's clothing, timeless jewellery, statement accessories, and prestige skincare favourites.
              </p>
            </div>

            {/* Quick Links */}
            <div className="md:col-span-3 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#E6D3A3]">
                Curated Categories
              </h4>
              <ul className="space-y-2 text-sm text-stone-400">
                <li>
                  <button 
                    onClick={() => handleAffiliateClick('clothing', "Footer Women's Clothing", notify)}
                    className="hover:text-[#C6A15B] transition-colors cursor-pointer text-left"
                  >
                    Women's Clothing &rarr;
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => handleAffiliateClick('jewelry', 'Footer Jewellery', notify)}
                    className="hover:text-[#C6A15B] transition-colors cursor-pointer text-left"
                  >
                    Jewellery &amp; Accessories &rarr;
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => handleAffiliateClick('skincare', 'Footer Skincare', notify)}
                    className="hover:text-[#C6A15B] transition-colors cursor-pointer text-left"
                  >
                    Skincare &amp; Beauty &rarr;
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => handleAffiliateClick('affiliateProgram', 'Footer Creator Program', notify)}
                    className="text-[#C6A15B] hover:underline transition-colors cursor-pointer text-left font-medium"
                  >
                    Become an Affiliate &rarr;
                  </button>
                </li>
              </ul>
            </div>

            {/* Quick Jump */}
            <div className="md:col-span-3 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#E6D3A3]">
                Navigation
              </h4>
              <ul className="space-y-2 text-sm text-stone-400">
                <li>
                  <button 
                    onClick={() => scrollTo('home')}
                    className="hover:text-[#C6A15B] transition-colors cursor-pointer"
                  >
                    Back to Top
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollTo('trending')}
                    className="hover:text-[#C6A15B] transition-colors cursor-pointer"
                  >
                    Trending Finds
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollTo('monetize')}
                    className="hover:text-[#C6A15B] transition-colors cursor-pointer"
                  >
                    Monetization Guide
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollTo('discovery')}
                    className="hover:text-[#C6A15B] transition-colors cursor-pointer"
                  >
                    Style Gallery
                  </button>
                </li>
              </ul>
            </div>

          </div>

          {/* Mandatory Affiliate Disclosure Section (PRESERVED & ENHANCED) */}
          <div id="affiliate-disclosure" className="p-6 bg-[#171717] rounded-xl border border-stone-800 space-y-2 text-xs text-stone-400 leading-relaxed">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#C6A15B]" />
              <p className="font-bold text-stone-200 uppercase tracking-wider text-[11px] text-[#C6A15B]">
                Affiliate Disclosure Notice
              </p>
            </div>
            <p>
              Queen of Fashion participates in affiliate marketing programs. We may earn a commission when you purchase through qualifying links provided on this site, at no additional cost to you. We curate and recommend items based on personal taste and style inspiration. Earnings depend on individual affiliate partner program requirements, approved referrals, and qualifying purchases.
            </p>
          </div>

          {/* Bottom Copyright & Notes */}
          <div className="pt-6 border-t border-stone-800 flex flex-col sm:flex-row justify-between items-center text-xs text-stone-500 gap-4">
            <p>&copy; {new Date().getFullYear()} Queen of Fashion. All rights reserved.</p>
            <p className="text-[11px]">Gold Standard Fashion Finds · Handpicked for modern elegance</p>
          </div>

        </div>
      </footer>

      {/* ========================================================== */}
      {/* MOBILE STICKY CTA BAR (Only on mobile, < 15% viewport)     */}
      {/* ========================================================== */}
      <aside 
        aria-label="Mobile quick shopping action"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0D0D0D]/95 backdrop-blur-md border-t border-[#C6A15B]/40 px-4 py-2.5 shadow-2xl flex items-center justify-between gap-3"
      >
        <div className="flex items-center gap-2">
          <Crown className="w-4 h-4 text-[#C6A15B]" />
          <div className="flex flex-col">
            <span className="text-[11px] font-bold text-white leading-tight">Queen of Fashion</span>
            <span className="text-[9px] text-[#E6D3A3] uppercase tracking-wider">Weekly Finds</span>
          </div>
        </div>

        <button
          onClick={() => scrollTo('trending')}
          className="flex-1 max-w-[210px] py-2.5 px-4 bg-gradient-to-r from-[#C6A15B] via-[#E6D3A3] to-[#B8924B] text-[#0D0D0D] font-bold text-xs uppercase tracking-wider rounded-full shadow-lg flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <span>🛍 Shop Trending Finds</span>
        </button>
      </aside>

    </div>
  );
}
